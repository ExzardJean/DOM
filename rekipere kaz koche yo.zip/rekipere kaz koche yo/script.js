const countryArray = ["Haiti", "France", "United States", "Belgium", "Canada", "Jamaica", "Mexico", "Brazil", "Nigeria"];



function genere(table) {
    let ordoneliste = document.getElementById('liste')

    let monMap = new Map()

    for (let i = 0; i < table.length; i++) {

        let li = document.createElement('li')
        li.setAttribute('name','liName')
        let input = document.createElement('input')
        input.setAttribute('type', 'checkbox')
        input.setAttribute('name', 'checkbox')
        li.append(input)
        li.setAttribute('id', `monli${i}`)
        let tempon = monMap.set(`monli${i}`, countryArray[i])
        let value = tempon.get(`monli${i}`)
        input.setAttribute('value',`${value}`)
        li.append(value)
        ordoneliste.append(li)
    }
}
(genere(countryArray))

let form =document.querySelector('form');
form.addEventListener('submit',(event)=>{
    event.preventDefault()
    let affichage2=document.createElement('div')
    affichage2.setAttribute('id','affichage')
    let data =new FormData(form)
    let choix=(data.get('checkbox'))
    const nodeChoices =
    form.querySelectorAll('input[name=checkbox]:checked')
     let choices = []
     for(let i = 0; i<nodeChoices.length;i++){
     choices.push( nodeChoices[i].value )
     }
     
    let affichage =document.getElementById('affichage')
      affichage.innerText=`${choices}`
     // affichage.style="margin bottom: 5px"
})




