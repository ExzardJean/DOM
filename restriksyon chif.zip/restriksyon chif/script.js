verif = (str) => {
    let bool = true
    for (let i = 0; i < str.length; i++) {
        if (Number(str[i])) {
            continue;
        }
        else {
            bool = false
            break
        }

    }
    return bool;
}

karak = (str) => {
    let bool = true
    let tab = '!@#$%^&*()_+=<>?|{}[]`~,./;\'';

    for (let i = 0; i < str.length; i++) {
        if (tab.includes(str[i])) {
            bool = false
            break
        }
        else
            continue;
    }
    return bool;
}

champ.addEventListener('input', (event) => {
    const incorrect = document.getElementById('chif')
    let rekipere = event.target.value
    if (rekipere.length == 0) {
        incorrect.innerText = 'ce champ est obligatoire'
        incorrect.style.cssText = 'color:#f44336'
        champ.style.cssText = 'border: 2px solid  #f44336 ;border-radius:5px'
    }
    else if (!verif(rekipere)) {
        incorrect.innerText = 'le champ doit contenir des chiffres '
        incorrect.style.cssText = 'color:#f44336'
        champ.style.cssText = 'border: 2px solid  #f44336 ;border-radius:5px'
    }
    else if (!karak(rekipere)) {
        incorrect.innerText = 'pas de caracteres speciaux'
        incorrect.style.cssText = 'color:#f44336'
        champ.style.cssText = 'border: 2px solid  #f44336 ;border-radius:5px'
    }

    else if (rekipere.length != 8) {
        incorrect.innerText = 'le champ doit contenir au plus 8 chiffres'
        incorrect.style.cssText = 'color:#f44336'
        champ.style.cssText = 'border: 2px solid  #f44336 ;border-radius:5px'
    }



    else {
        champ.style.cssText = 'border-radius:2px'
        incorrect.style.cssText = 'display:none'

    }
})